
import PogObject from "PogData"

const settings = new PogObject("AttributeOverlay", {
    hideAll: false,
    attributeList: {}
})

register("command", (...args) => {
    switch(args[0]){
        case null:
            return
        case "add":
            if(!args[2]){ 
                ChatLib.chat("&4example usage: /attributes add mana_pool &4") 
                return
            }
            settings.attributeList[args[1]] = {
                color: args[2]
            }
            
            settings.save()
            return
        case "delete":
            delete settings.attributeList[args[1]]
            settings.save()
            return
        case "toggle":
            settings.hideAll = !settings.hideAll
            if(settings.hideAll){
                ChatLib.chat("&2Attribute overlay On")
            } else {
                ChatLib.chat("&4Attribute overlay Off")
            }
            settings.save()
            return
        case "held":
            let attributes = Player.getHeldItem()?.getNBT()?.get("tag")?.get("ExtraAttributes")?.get("attributes")?.toObject()
            ChatLib.chat("Attributes: " + JSON.stringify(attributes))
            return
    }

}).setName("attributes")

register("renderItemIntoGui", (item, x, y, event) => {
    attributes = item.getNBT()?.get("tag")?.get("ExtraAttributes")?.get("attributes")?.toObject()

    if(!settings.hideAll) return
    if(!Client.isInGui()) return
    if(!attributes) return

    let renderX = x + 5 
    let renderY = y 
    
    if(settings.attributeList.hasOwnProperty(Object.keys(attributes)[0])){
        let properties = settings.attributeList[Object.keys(attributes)[0]]
        drawOutlinedString(properties["color"] + attributes[Object.keys(attributes)[0]], renderX, renderY, 1, 500)

        renderX += 0
        renderY += 9
    } 
    if(settings.attributeList.hasOwnProperty(Object.keys(attributes)[1])){
        let properties = settings.attributeList[Object.keys(attributes)[1]]
        drawOutlinedString(properties["color"] + attributes[Object.keys(attributes)[1]], renderX, renderY, 1, 500)
    } 
})



function drawOutlinedString(text,x1,y1,scale,z) {
    let outlineString = "&0" + ChatLib.removeFormatting(text)
    let x = x1/scale
    let y = y1/scale

    Renderer.translate(0,0,z)
    Renderer.scale(scale,scale)
    Renderer.drawString(outlineString, x + 1, y)

    Renderer.translate(0,0,z)
    Renderer.scale(scale,scale)
    Renderer.drawString(outlineString, x - 1, y)

    Renderer.translate(0,0,z)
    Renderer.scale(scale,scale)
    Renderer.drawString(outlineString, x, y + 1)

    Renderer.translate(0,0,z)
    Renderer.scale(scale,scale)
    Renderer.drawString(outlineString, x, y - 1)

    Renderer.translate(0,0,z)
    Renderer.scale(scale,scale)
    Renderer.drawString(text, x, y)
}