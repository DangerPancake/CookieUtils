# BetterMap
Bettermap is a highly advanced dungeon map that attempts to show you the most information that it can find about the dungeon, without the map being a cheat.

Easiest installation method is to have the ChatTriggers mod and run `/ct import bettermap`

[Discord](https://discord.gg/Uq5YzpaMsr)

![Image of map and settings menu](https://imagedelivery.net/aG82t-qDLn415HP9HHoOeg/b228f0da-b16d-43f1-be9d-2f9e674ff600/original)

![Image of end of run cleared rooms](https://cdn.discordapp.com/attachments/997954712978604054/1022068477449732116/unknown.png)
![Image of hovering end of run cleared rooms](https://cdn.discordapp.com/attachments/997954712978604054/1022068477827235860/unknown.png)

![Shows more info when hovering on a room](https://cdn.discordapp.com/attachments/783682572882411560/1026681245947662397/unknown.png)
