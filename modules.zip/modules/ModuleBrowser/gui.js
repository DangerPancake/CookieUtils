import {
  Window,
  UIText,
  UITextInput,
  UIContainer,
  RelativeConstraint,
  CenterConstraint,
  ConstantColorConstraint,
  UIBlock,
  PixelConstraint,
  AdditiveConstraint,
  SiblingConstraint,
  UIRoundedRectangle,
  FillConstraint,
  ScrollComponent,
  ScissorEffect,
  ChildBasedMaxSizeConstraint,
  AspectConstraint,
  ChildBasedSizeConstraint,
  Animations,
} from "../Elementa";

const Color = Java.type("java.awt.Color");

export default class ModulesGUI {
  /**
   *
   * @param {import('./controller').default} controller
   */
  constructor(controller) {
    this.controller = controller;
    this.gui = new Gui();

    this.GuiKeybind = new KeyBind(
      "Open Modules Gui",
      Keyboard.KEY_M,
      "Module Browser"
    );

    this.lastPress = Date.now();

    this.sortMode = this.controller.sortModes[0].value;
    this.lastSearch = "";

    this.debounceTimer = new java.util.Timer();
    this.debouncer = false;

    this.screenWidth = Renderer.screen.getWidth();
    this.screenHeight = Renderer.screen.getHeight();

    this.windowWidth = this.screenWidth / 2;
    this.windowHeight = this.screenHeight * 0.9;

    this.screenXPos = this.screenWidth / 2 - this.windowWidth / 2;
    this.screenYPos = this.screenHeight / 2 - this.windowHeight / 2;

    this.previousBlockColor = false;

    register("tick", () => {
      if (this.GuiKeybind.isPressed()) {
        this.open();
      }
    });

    this.title = new UIText("Modules")
      .setX((8).pixels())
      .setY((5).pixels())
      .setTextScale((2).pixels());

    this.topLine = new UIBlock(new Color(1, 1, 1, 0.3))
      .setWidth(new RelativeConstraint())
      .setHeight((3).pixels())
      .setY(new AdditiveConstraint(new SiblingConstraint(), (10).pixels()));

    this.searchBar = new UITextInput("Search modules...")
      .setWidth(new RelativeConstraint())
      .setHeight((25).pixels())
      .setY(new CenterConstraint())
      .setX((5).pixels())
      .onUpdate((input) => {
        this.doDebounce(input);
      });

    this.dropdownState = false;

    this.searchBarContainer = new UIBlock()
      .setWidth(new RelativeConstraint(0.95))
      .setHeight(new RelativeConstraint(0.05))
      .setColor(new ConstantColorConstraint(new Color(1, 1, 1, 0.1)))
      .setX(new CenterConstraint())
      .setY(new SiblingConstraint().to(this.topLine))
      .addChildren(
        this.searchBar,
        // this.sortDropdown,
        new UIBlock() // x button
          .setWidth(new AspectConstraint())
          .setHeight(new RelativeConstraint(0.7))
          .setX(new PixelConstraint(5, true))
          .setY(new CenterConstraint())
          .setColor(new ConstantColorConstraint(new Color(1, 1, 1, 0.1)))
          .addChild(
            new UIText("x")
              .setX(new CenterConstraint())
              .setY(new CenterConstraint())
          )
          .onMouseClick((x, y, button) => {
            if (button == 0) {
              this.lastSearch = "";
              this.resetList();
              this.searchBar.setText("");
            }
          })
      );

    this.sortDropdown = new UIBlock() // dropdown button
      .setWidth((160).pixels())
      .setHeight(new RelativeConstraint(0.7).to(this.searchBarContainer))
      .setX(new PixelConstraint(32, true).to(this.searchBarContainer))
      .setY(new CenterConstraint().to(this.searchBar))
      .setColor(new ConstantColorConstraint(new Color(1, 1, 1, 0.1)))
      .addChildren(
        new UIText(`Sort By: ${this.controller.sortModes[0].name} `)
          .setX(new CenterConstraint())
          .setY(new CenterConstraint()),
        new UIText("▽")
          .setX(new SiblingConstraint())
          .setY(new CenterConstraint())
          .setTextScale((2).pixels()),
        new UIBlock()
          .setWidth(new FillConstraint())
          .setHeight((0).pixels())
          .setY(
            new AdditiveConstraint(
              new SiblingConstraint(),
              new SiblingConstraint()
            )
          )
          .enableEffect(new ScissorEffect())
          .setColor(new ConstantColorConstraint(new Color(0.5, 0.5, 0.5, 1)))
          .addChildren
          // new UIText("Newest to oldest")
          //   .setX(new CenterConstraint())
          //   .setY(new SiblingConstraint()),
          // new UIText("Oldest to newest")
          //   .setX(new CenterConstraint())
          //   .setY(new SiblingConstraint())
          ()
          .onMouseEnter(() => {
            this.dropdownState = true;
          })
          .onMouseLeave(() => {
            this.dropdownState = false;
            let dropdownBox = this.sortDropdown.children[2];
            let anim = dropdownBox.makeAnimation();
            anim.setHeightAnimation(Animations.OUT_EXP, 1, (0).pixels());
            anim.begin();
          })
      )
      .onMouseEnter(() => {
        let dropdownBox = this.sortDropdown.children[2];
        let anim = dropdownBox.makeAnimation();
        anim.setHeightAnimation(
          Animations.OUT_EXP,
          1,
          new ChildBasedSizeConstraint()
        );
        anim.begin();
      })
      .onMouseLeave(() => {
        if (this.dropdownState) return;
        let dropdownBox = this.sortDropdown.children[2];
        let anim = dropdownBox.makeAnimation();
        anim.setHeightAnimation(Animations.OUT_EXP, 1, (0).pixels());
        anim.begin();
      });

    this.controller.sortModes.forEach((mode, index) => {
      let elem = new UIBlock()
        // .setY(new SiblingConstraint())
        .setWidth(new FillConstraint())
        .setHeight((12).pixels())
        .addChild(
          new UIText(mode.name)
            .setX(new CenterConstraint())
            .setY(new CenterConstraint())
        )
        .onMouseEnter(() => {
          elem.setColor(new ConstantColorConstraint(new Color(0, 0, 0, 0.2)));
        })
        .onMouseLeave(() => {
          elem.setColor(new ConstantColorConstraint(new Color(0, 0, 0, 0)));
        })
        .onMouseClick((x, y, button) => {
          if (button === 0) this.setSortMode(mode);
        });
      if (index > 0) elem.setY(new SiblingConstraint());
      this.sortDropdown.children[2].addChild(elem);
    });

    this.modulesList = new ScrollComponent()
      .setWidth(new RelativeConstraint())
      .setHeight(new FillConstraint())
      .setY(new SiblingConstraint())
      .addChild(new UIContainer());

    this.background = new UIRoundedRectangle(2)
      .setColor(new ConstantColorConstraint(new Color(0.1, 0.1, 0.1, 0.75)))
      .setWidth(new RelativeConstraint(0.5))
      .setHeight(new RelativeConstraint(0.9))
      .setX(new CenterConstraint())
      .setY(new CenterConstraint())
      .addChildren(
        this.title,
        this.topLine,
        this.searchBarContainer,
        this.modulesList,
        this.sortDropdown // TODO: move for elementa v2
      );

    this.window = new Window().addChild(this.background);

    this.searchBar.setActive(true);

    this.gui.registerDraw((x, y) => this.draw());
    this.gui.registerClicked((x, y, b) => this.window.mouseClick(x, y, b));
    this.gui.registerMouseDragged((x, y, b) => this.window.mouseDrag(x, y, b));
    this.gui.registerScrolled((x, y, s) => this.window.mouseScroll(s));
    this.gui.registerMouseReleased((x, y, b) => this.window.mouseRelease());
    this.gui.registerKeyTyped((char, key) => this.window.keyType(char, key));
  }

  setSortMode(mode) {
    this.sortMode = mode.value;
    this.sortDropdown.children[0].setText(`Sort By: ${mode.name} `);
    if (this.lastSearch == "") return;
    this.resetList();
    let modules = this.controller.fetchModules(
      this.lastSearch == "HOMEPAGE" ? "" : this.lastSearch,
      this.sortMode
    );
    for (let module of modules) {
      this.addModule(module);
    }
  }

  open() {
    this.gui.open();
    this.showHomePage();
  }

  showHomePage() {
    if (this.lastSearch != "") return;
    this.lastSearch = "HOMEPAGE";
    let modules = this.controller.fetchModules("");
    this.resetList();
    for (let module of modules) {
      this.addModule(module);
    }
  }

  doDebounce(input) {
    if (Date.now() - this.lastPress < 10) return;
    this.lastPress = Date.now();
    if (this.debouncer) {
      this.debouncer.cancel();
      this.debounceTimer.purge();
    }
    this.debouncer = new JavaAdapter(java.util.TimerTask, {
      run: () => {
        if (input == this.lastSearch) return (this.debouncer = false);
        this.lastSearch = input;
        if (!input.length) {
          this.resetList();
          this.debouncer = false;
          return;
        }
        this.resetList();
        let modules = this.controller.fetchModules(input, this.sortMode);
        for (let module of modules) {
          this.addModule(module);
        }
        this.debouncer = false;
      },
    });
    try {
      this.debounceTimer.schedule(this.debouncer, 250);
    } catch (e) {
      this.debouncer = false;
      this.debounceTimer.purge();
    }
  }

  draw() {
    Renderer.drawRect(
      Renderer.color(0, 0, 0, 60),
      0,
      0,
      Renderer.screen.getWidth(),
      Renderer.screen.getHeight()
    );
    this.window.draw();
  }

  /**
   * Reset the modules list
   */
  resetList() {
    this.previousBlockColor = false;
    this.modulesList.children[0].clearChildren();
  }

  /**
   * Create a module block to be added to the list.
   * @param {String} name
   */
  addModule(module) {
    this.previousBlockColor = !this.previousBlockColor;
    const block = new UIBlock()
      .setWidth(new RelativeConstraint())
      .setHeight(new RelativeConstraint(0.1))
      .setY(new SiblingConstraint())
      .addChildren(
        new UIContainer()
          .setWidth(new RelativeConstraint(0.95))
          .setHeight(new RelativeConstraint(0.9))
          .setX(new CenterConstraint())
          .setY(new CenterConstraint())
          .addChildren(
            new UIText(module.name)
              .setTextScale((1).pixels())
              .setY(new CenterConstraint()),
            new UIBlock()
              .setWidth((55).pixels())
              .setHeight(new RelativeConstraint(0.8))
              .setX(new PixelConstraint(0, true))
              .setY(new CenterConstraint())
              .setColor(
                module.imported
                  ? new ConstantColorConstraint(new Color(0, 0, 0, 0.2))
                  : new ConstantColorConstraint(new Color(1, 1, 1, 0.1))
              )
              .addChild(
                new UIText(module.imported ? "Imported" : "Import")
                  .setX(new CenterConstraint())
                  .setY(new CenterConstraint())
                  .setColor(
                    module.imported
                      ? new ConstantColorConstraint(new Color(1, 1, 1, 0.7))
                      : new ConstantColorConstraint(new Color(1, 1, 1))
                  )
              )
              .onMouseClick((x, y, button) => {
                if (button == 0) this.controller.downloadModule(module.name);
              })
          )
      );

    if (this.previousBlockColor)
      block.setColor(
        new ConstantColorConstraint(new Color(0.1, 0.1, 0.1, 0.5))
      );
    this.modulesList.children[0].addChild(block);
  }
}
