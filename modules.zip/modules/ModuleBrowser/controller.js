import PlayerGui from "./gui";

export default class BrowserController {
  constructor() {
    this.searchURL =
      "https://chattriggers.com/api/modules?limit=50&offset=0&tags=&q=$INPUT&sort=$SORT";

    this.sortModes = [
      {
        name: "Newest to oldest",
        value: "DATE_CREATED_DESC",
      },
      {
        name: "Oldest to newest",
        value: "DATE_CREATED_ASC",
      },
      {
        name: "Most downloads",
        value: "DOWNLOADS_DESC",
      },
      {
        name: "Least downloads",
        value: "DOWNLOADS_ASC",
      },
    ];
    this.playerGui = new PlayerGui(this);
  }

  /**
   * Download a module by name
   * @param {String} moduleName
   */
  downloadModule(moduleName = null) {
    ChatLib.command("ct import " + moduleName, true);
  }

  /**
   * Search modules
   * @param {String} input
   */
  fetchModules(input, sortMode = "DATE_CREATED_DESC") {
    const content = FileLib.getUrlContent(
      this.searchURL.replace("$INPUT", input).replace("$SORT", sortMode)
    );
    const data = JSON.parse(content);

    const ctVersion = ChatTriggers.MODVERSION.split(".").map((v) =>
      parseInt(v)
    );
    const importedModules = Java.type(
      "com.chattriggers.ctjs.engine.module.ModuleManager"
    ).INSTANCE.cachedModules.map((m) => m.name.toLowerCase());
    const modules = data.modules
      .filter((module) => module.releases.length)
      .filter((module) => {
        const releases = module.releases.filter((release) => {
          const modVersion = release.modVersion
            .split(".")
            .map((v) => parseInt(v));
          if (ctVersion[0] != modVersion[0]) return false;
          if (ctVersion[1] < modVersion[1]) return false;
          if (ctVersion[2] < modVersion[2]) return false;
          return true;
        });
        return releases.length;
      })
      .map((m) => ({
        ...m,
        imported: importedModules.includes(m.name.toLowerCase()),
      }));
    return modules;
  }
}
