/// <reference types="../CTAutocomplete" />
/// <reference lib="es2015" />

import BrowserController from "./controller";

const controller = new BrowserController();

register("command", (arg1, ...arg2) => {
  controller.playerGui.open();
}).setName("modules");
