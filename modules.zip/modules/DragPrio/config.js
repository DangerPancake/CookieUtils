import { @Vigilant, @SliderProperty, @SwitchProperty, @SelectorProperty } from 'Vigilance'


export const dragInfo = {

    POWER: { dragColor: "RED", renderColor: Renderer.RED, prio: [1, 3], spawned: false, easy: false },
    FLAME: { dragColor: "ORANGE", renderColor: Renderer.GOLD, prio: [2, 1], spawned: false, easy: true },
    ICE: { dragColor: "BLUE", renderColor: Renderer.BLUE, prio: [3, 4], spawned: false, easy: false },
    SOUL: { dragColor: "PURPLE", renderColor: Renderer.LIGHT_PURPLE, prio: [4, 5], spawned: false, easy: true },
    APEX: { dragColor: "GREEN", renderColor: Renderer.GREEN, prio: [5, 2], spawned: false, easy: true },
}

@Vigilant("DragPrio")

class Settings {
    constructor() {
        this.initialize(this);
        this.setCategoryDescription("General", "If you encounter any bugs or want any features added feel free to dm us on disc @bxsy/@tbone222 or msg us in game Bxsy/T_Bone222\n\n&bDo /sendprio to share your prio with your party")
        this.setSubcategoryDescription("General", "Main", "Main stuff")
        this.setSubcategoryDescription("General", "Normal Teams", "Set which team tank and healer go with on a normal split.")
        this.setSubcategoryDescription("General", "Purple Teams", "Set which team tank and healer go with when purple spawns.")
    }

    @SliderProperty({
        name: "Set Power",
        description: "Set the power that you split on",
        category: "General",
        subcategory: "Main",
        min: 0,
        max: 32
    })
    splitPower = 22;

    @SliderProperty({
        name: "Set Easy Power",
        description: "Set the power that you split on for easy drags (O/P/G)",
        category: "General",
        subcategory: "Main",
        min: 0,
        max: 32
    })
    easyPower = 19;

    @SwitchProperty({
        name: "Show Non-Split drags",
        description: "Display \"X Dragon is spawning!\" on non-split drags",
        category: "General",
        subcategory: "Main"
    })
    showSingleDragons = true;

    @SwitchProperty({
        name: "Send Split Message",
        description: "Send the \"Bers Team: Arch Team:\" message",
        category: "General",
        subcategory: "Main"
    })
    sendMessage = false;

    @SwitchProperty({
        name: "Say Split",
        description: "Send \"Split\" when splitting",
        category: "General",
        subcategory: "Main"
    })
    saySplit = true;

    @SelectorProperty({
        name: "Healer",
        description: "Set the team the healer will go with",
        category: "General",
        subcategory: "Normal Teams",
        options: ["Arch Team", "Bers Team"]
    })
    healerNormal = 0;

    @SelectorProperty({
        name: "Tank",
        description: "Set the team the tank will go with",
        category: "General",
        subcategory: "Normal Teams",
        options: ["Arch Team", "Bers Team"]
    })
    tankNormal = 0;

    @SelectorProperty({
        name: "Healer",
        description: "Set the team the healer will go with when purple",
        category: "General",
        subcategory: "Purple Teams",
        options: ["Arch Team", "Bers Team"]
    })
    healerPurp = 1;

    @SelectorProperty({
        name: "Tank",
        description: "Set the team the tank will go with when purple",
        category: "General",
        subcategory: "Purple Teams",
        options: ["Arch Team", "Bers Team"]
    })
    tankPurp = 0;

    @SwitchProperty({
        name: "First Load",
        description: "Check ",
        category: "General",
        subcategory: "Main",
    })
    firstLoad = true;


}

export default new Settings()
