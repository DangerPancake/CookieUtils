/// <reference types="../CTAutocomplete" />
import './firstLoad'
import './commands'
import './config'
import './utils'
import { getTime, getTruePower, getPower, getClass } from './utils'
import { dragInfo } from './config'
import Settings from './config'


// stuff
let search = false
let drags = [null, null]
let showText = false
let bersTeam = false
let purpleSpawn = false
let healer = false
let tank = false
let text = new Text("")


// function to check if the split drags are soul/flame/apex (easy split)
function isEasySplit() {

  return (drags[0].easy && drags[1].easy)
}


// function to check if block pos is in a correct location
function checkBlockPos(x, y, z) {

  // check if correct height
  if (!(y >= 14 && y <= 19)) return

  // check if red/green
  if (x >= 27 && x <= 32) {

    // check if red
    if (z == 59) {

      if (!(dragInfo.POWER.spawned)) {

        dragInfo.POWER.spawned = true
        assignDrag(dragInfo.POWER)
        setTimeout(() => {

          dragInfo.POWER.spawned = false
        }, 8000)
      }

      // check if green
    } else if (z == 94) {

      if (!(dragInfo.APEX.spawned)) {

        dragInfo.APEX.spawned = true
        assignDrag(dragInfo.APEX)
        setTimeout(() => {

          dragInfo.APEX.spawned = false
        }, 8000)
      }
    }

    // check if blue/orange
  } else if (x >= 79 && x <= 85) {

    // check if blue
    if (z == 94) {

      if (!(dragInfo.ICE.spawned)) {

        dragInfo.ICE.spawned = true
        assignDrag(dragInfo.ICE)
        setTimeout(() => {

          dragInfo.ICE.spawned = false
        }, 8000)
      }

      // check if orange
    } else if (z == 56) {

      if (!(dragInfo.FLAME.spawned)) {

        dragInfo.FLAME.spawned = true
        assignDrag(dragInfo.FLAME)
        setTimeout(() => {

          dragInfo.FLAME.spawned = false
        }, 8000)
      }
    }

    // check if purple    
  } else if (x == 56) {

    if (!(dragInfo.SOUL.spawned)) {

      dragInfo.SOUL.spawned = true
      purpleSpawn = true
      assignDrag(dragInfo.SOUL)
      setTimeout(() => {

        dragInfo.SOUL.spawned = false
      }, 8000)
    }
  }
}


// getting drag objects & calls determinePrio once both drags have been grabbed, if drags is full (first two alr spawned) it just displays the spawning drag if enabled
function assignDrag(drag) {

  if (drags[0] == null) {

    drags[0] = drag
  } else if (drags[1] == null) {

    drags[1] = drag
    determinePrio()
  }
  else if (Settings.showSingleDragons) {

    text = new Text(`${drag.dragColor} IS SPAWNING!`).setScale(5).setColor(drag.renderColor).setShadow(true)

    showText = true
    setTimeout(() => {

      showText = false
    }, 2000)
  }
}


// determines drag priority, split/no split, & calls displayDragon once complete
function determinePrio() {

  let normalDrag = (drags[0].prio[0] < drags[1].prio[0] ? drags[0] : drags[1])
  let truePower = getTruePower()
  let split = 0

  if (truePower >= Settings.splitPower) {

    split = 1
  } else if (isEasySplit() && truePower >= Settings.easyPower) {

    split = 1
  }

  // if drag 1 is leftmost dragon (higher prio)
  if (drags[0].prio[split] < drags[1].prio[split]) {

    bersDrag = drags[0]
    archDrag = drags[1]
  } else {

    bersDrag = drags[1]
    archDrag = drags[0]
  }

  displayDragon(bersDrag, archDrag, normalDrag, split)
}


// display title on screen and say party msg if enabled
function displayDragon(bersDrag, archDrag, normalDrag, split) {

  if (Settings.sendMessage && split) {

    // shut up ik
    ChatLib.command(`pc BERS TEAM --> ${bersDrag.dragColor}
      
                       ARCH TEAM --> ${archDrag.dragColor}`)
  }

  if (split) {

    if ((bersTeam) || (purpleSpawn && ((healer && Settings.healerPurp == 1) || (tank && Settings.tankPurp == 1)))) {

      text = new Text(`${bersDrag.dragColor} IS SPAWNING!`).setScale(5).setColor(bersDrag.renderColor).setShadow(true)
    } else {

      text = new Text(`${archDrag.dragColor} IS SPAWNING!`).setScale(5).setColor(archDrag.renderColor).setShadow(true)
    }
  } else {

    text = new Text(`${normalDrag.dragColor} IS SPAWNING!`).setScale(5).setColor(normalDrag.renderColor).setShadow(true)
  }

  showText = true
  setTimeout(() => {

    showText = false
  }, 2000)
}


// checks and updates some stuff on p5 start
register('chat', () => {

  drags = [null, null]
  purpleSpawn = false
  bersTeam = false
  healer = false
  tank = false
  dragInfo.POWER.spawned = false
  dragInfo.FLAME.spawned = false
  dragInfo.ICE.spawned = false
  dragInfo.SOUL.spawned = false
  dragInfo.APEX.spawned = false

  let selectedClass = getClass(Player.getName())

  if (selectedClass[0] == 'B' || selectedClass[0] == 'M') {

    bersTeam = true
  } else if (selectedClass[0] == 'H') {

    healer = true

    if (Settings.healerNormal == 1) {

      bersTeam = true
    }
  } else if (selectedClass[0] == 'T') {

    tank = true

    if (Settings.tankNormal == 1) {

      bersTeam = true
    }
  } else {

    bersTeam = false
  }

  // say split message if enabled
  setTimeout(() => {

    if (Settings.saySplit) {

      let power = getTruePower()

      if (power >= Settings.splitPower) {

        ChatLib.command(`pc Power: ${power} || Split on all drags!`)
      } else if (power >= Settings.easyPower) {

        ChatLib.command(`pc Power: ${power} || Split on easy drags!`)
      } else {

        ChatLib.command(`pc Power: ${power} || No split!`)
      }
    }
  }, 2000)


  // start searching for particles
  search = true
}).setCriteria(/(.+)&r&a picked the &r&cCorrupted Blue Relic&r&a!&r/)



// getting server packers and cheching if they are flame particles
register("packetReceived", (packet) => {

  // func is getting particle type
  if (search && packet.func_179749_a().toString() == "ENCHANTMENT_TABLE") {

    // funcs are x, y, and z cords
    checkBlockPos(parseInt(packet.func_149220_d()), parseInt(packet.func_149226_e()), parseInt(packet.func_149225_f()))
  }

}).setFilteredClass(net.minecraft.network.play.server.S2APacketParticles)


// text rendering stuff
register('renderOverlay', () => {

  if (showText) {

    text.draw((Renderer.screen.getWidth() - text.getWidth()) / 2, (Renderer.screen.getHeight() - text.getHeight()) / 2 - 2)
  }
})


// resetting search on world load
register('worldLoad', () => {

  search = false
})

register('chat', (ign, Spower, Seasy, healerN, healerP, tankN, tankP) => {
  if (ign.equals(Player.getName())) { return }
  Client.scheduleTask(3, () => {
    new Message().addTextComponent(new TextComponent(`&2&l${ign} has sent their prio, click this message to accept`).setClickValue(`/setprio ${Spower} ${Seasy} ${healerN} ${healerP} ${tankN} ${tankP}`).setClickAction('run_command')).chat()
  })
}).setCriteria('${*} ${*} ${ign}: DP Settings: Power: ${Spower} | Easy: ${Seasy} | Healer: ${healerN} : ${healerP} | Tank: ${tankN} : ${tankP}')
