rm -rf ~/Desktop/BloomCore.zip
zip -r ~/Desktop/BloomCore.zip BloomCore/ -x BloomCore/data/* BloomCore/data.json *.git* -o